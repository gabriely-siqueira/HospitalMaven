package model.DAO;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Quarto;
import model.Ala;

public class QuartoDAO implements InterfaceDAO<Quarto> {

   @Override
   public void create(Quarto objeto) {
        if (objeto.getDescricao() == null || objeto.getDescricao().isEmpty()) {
            System.out.println("O campo descricao não pode ser vazio.");
            return; // Ou lançar uma exceção customizada
        }

        if (objeto.getStatus() == null || objeto.getStatus().isEmpty()) {
            System.out.println("O campo status não pode ser vazio.");
            return;
        }

        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;

        try {
            String sqlInstrucao = "INSERT INTO quarto (descricao, status, idAla) VALUES (?, ?, ?)";

            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, objeto.getDescricao());
            pstm.setString(2, objeto.getStatus());
            pstm.setInt(3, objeto.getAla() != null ? objeto.getAla().getId() : 0); // Associa a ala, caso tenha
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }

    @Override
    public List<Quarto> retrieve() {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        List<Quarto> listaQuarto = new ArrayList<>();

        String sqlInstrucao = "SELECT id, descricao, status, idAla FROM quarto";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            resultado = pstm.executeQuery();
            while (resultado.next()) {
                Quarto quarto = new Quarto();
                quarto.setId(resultado.getInt("id"));
                quarto.setDescricao(resultado.getString("descricao"));
                quarto.setStatus(resultado.getString("status"));

                // Carregar a ala associada ao quarto
                int idAla = resultado.getInt("idAla");
                if (idAla > 0) { // Verifica se a ala existe
                    Ala ala = new AlaDAO().retrieve(idAla); // Recupera a ala pelo ID
                    quarto.setAla(ala); // Associa a ala ao quarto
                }

                listaQuarto.add(quarto);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return listaQuarto;
    }

    @Override
    public Quarto retrieve(int pk) {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        Quarto quarto = new Quarto();

        String sqlInstrucao = "SELECT id, descricao, status, idAla FROM quarto WHERE id = ?";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setInt(1, pk);
            resultado = pstm.executeQuery();
            while (resultado.next()) {
                quarto.setId(resultado.getInt("id"));
                quarto.setDescricao(resultado.getString("descricao"));
                quarto.setStatus(resultado.getString("status"));

                // Carregar a ala associada ao quarto
                int idAla = resultado.getInt("idAla");
                if (idAla > 0) { // Verifica se a ala existe
                    Ala ala = new AlaDAO().retrieve(idAla); // Recupera a ala pelo ID
                    quarto.setAla(ala); // Associa a ala ao quarto
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return quarto;
    }

    @Override
    public List<Quarto> retrieve(String parametro, String atributo) {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        List<Quarto> listaQuarto = new ArrayList<>();

        String sqlInstrucao = "SELECT id, descricao, status, idAla FROM quarto WHERE " + atributo + " LIKE ?";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, "%" + parametro + "%");
            resultado = pstm.executeQuery();
            while (resultado.next()) {
                Quarto quarto = new Quarto();
                quarto.setId(resultado.getInt("id"));
                quarto.setDescricao(resultado.getString("descricao"));
                quarto.setStatus(resultado.getString("status"));

                // Carregar a ala associada ao quarto
                int idAla = resultado.getInt("idAla");
                if (idAla > 0) { // Verifica se a ala existe
                    Ala ala = new AlaDAO().retrieve(idAla); // Recupera a ala pelo ID
                    quarto.setAla(ala); // Associa a ala ao quarto
                }

                listaQuarto.add(quarto);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return listaQuarto;
    }

    @Override
    public void update(Quarto objeto) {
        Connection conexao = ConnectionFactory.getConnection();
        String sqlInstrucao = "UPDATE quarto SET descricao = ?, status = ?, idAla = ? WHERE id = ?";
        PreparedStatement pstm = null;

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, objeto.getDescricao());
            pstm.setString(2, objeto.getStatus());
            pstm.setInt(3, objeto.getAla() != null ? objeto.getAla().getId() : 0); // Atualiza a ala
            pstm.setInt(4, objeto.getId());
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }

    @Override
    public void delete(Quarto objeto) {
        Connection conexao = ConnectionFactory.getConnection();
        String sqlInstrucao = "DELETE FROM quarto WHERE id = ?";
        PreparedStatement pstm = null;

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setInt(1, objeto.getId());
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }
}
