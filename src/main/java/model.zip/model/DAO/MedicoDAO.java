package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Medico;

public class MedicoDAO implements InterfaceDAO<Medico> {

    @Override
    public void create(Medico objeto) {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;

        try {
            String sqlInstrucao = "INSERT INTO medico (nome, crm, login, senha, email) VALUES (?, ?, ?, ?, ?)";
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, objeto.getNome());
            pstm.setString(2, objeto.getCrm());
            pstm.setString(3, objeto.getLogin());
            pstm.setString(4, objeto.getSenha());
            pstm.setString(5, objeto.getEmail());
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }

    @Override
    public List<Medico> retrieve() {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        List<Medico> listaMedico = new ArrayList<>();

        String sqlInstrucao = "SELECT id, nome, crm, login, email FROM medico";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            resultado = pstm.executeQuery();
            while (resultado.next()) {
                Medico medico = new Medico();
                medico.setId(resultado.getInt("id"));
                medico.setNome(resultado.getString("nome"));
                medico.setCrm(resultado.getString("crm"));
                medico.setLogin(resultado.getString("login"));
                medico.setEmail(resultado.getString("email"));
                listaMedico.add(medico);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return listaMedico;
    }

    @Override
    public Medico retrieve(int pk) {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        Medico medico = null;

        String sqlInstrucao = "SELECT id, nome, crm, login, email FROM medico WHERE id = ?";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setInt(1, pk);
            resultado = pstm.executeQuery();
            if (resultado.next()) {
                medico = new Medico();
                medico.setId(resultado.getInt("id"));
                medico.setNome(resultado.getString("nome"));
                medico.setCrm(resultado.getString("crm"));
                medico.setLogin(resultado.getString("login"));
                medico.setEmail(resultado.getString("email"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return medico;
    }

    @Override
    public List<Medico> retrieve(String parametro, String atributo) {
        Connection conexao = ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet resultado = null;
        List<Medico> listaMedico = new ArrayList<>();

        String sqlInstrucao = "SELECT id, nome, crm, login, email FROM medico WHERE " + atributo + " LIKE ?";

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, "%" + parametro + "%");
            resultado = pstm.executeQuery();
            while (resultado.next()) {
                Medico medico = new Medico();
                medico.setId(resultado.getInt("id"));
                medico.setNome(resultado.getString("nome"));
                medico.setCrm(resultado.getString("crm"));
                medico.setLogin(resultado.getString("login"));
                medico.setEmail(resultado.getString("email"));
                listaMedico.add(medico);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, resultado);
        }

        return listaMedico;
    }

    @Override
    public void update(Medico objeto) {
        Connection conexao = ConnectionFactory.getConnection();
        String sqlInstrucao = "UPDATE medico SET nome = ?, crm = ?, login = ?, email = ? WHERE id = ?";
        PreparedStatement pstm = null;

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, objeto.getNome());
            pstm.setString(2, objeto.getCrm());
            pstm.setString(3, objeto.getLogin());
            pstm.setString(4, objeto.getEmail());
            pstm.setInt(5, objeto.getId());
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }

    @Override
    public void delete(Medico objeto) {
        Connection conexao = ConnectionFactory.getConnection();
        String sqlInstrucao = "DELETE FROM medico WHERE id = ?";
        PreparedStatement pstm = null;

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setInt(1, objeto.getId());
            pstm.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm, null);
        }
    }
}
