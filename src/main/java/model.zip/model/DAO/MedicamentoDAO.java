    package model.DAO;

    import java.util.List;
    import model.Medicamento;
    import java.sql.Connection;
    import java.sql.PreparedStatement;
    import java.sql.SQLException;
    import java.sql.ResultSet;
    import java.util.ArrayList;


    public class MedicamentoDAO implements InterfaceDAO<Medicamento> {

        @Override
        public void create(Medicamento objeto) {
            Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement pstm = null;

            try {

                String sqlInstrucao = "Insert Into medicamento (descricaoMedicamento,"
                        + "principioAtivo,"
                        + "quantidadeMinima,"
                        + "status) "
                        + "Values(?,?,?,?) ";

                pstm = conexao.prepareStatement(sqlInstrucao);
                pstm.setString(1, objeto.getDescricaoMedicamento());
                pstm.setString(2, objeto.getPrincipioAtivo());
                pstm.setFloat(3, objeto.getQtdMinima());
                pstm.setString(4, objeto.getStatus());
                pstm.execute();
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                ConnectionFactory.closeConnection(conexao, pstm, null);
            }

        }

        @Override
        public List<Medicamento> retrieve() {

            Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement pstm = null;
            ResultSet resultado = null;
            List<Medicamento> listaMedicamento = new ArrayList<>();

            String sqlInstrucao = " Select id, descricaoMedicamento, principioAtivo, quantidadeMinima, status"
                    + " From medicamento ";

            try {
                pstm = conexao.prepareStatement(sqlInstrucao);
                resultado = pstm.executeQuery();
                while (resultado.next()) {
                    Medicamento medicamento = new Medicamento();
                    medicamento.setId(resultado.getInt("id"));
                    medicamento.setDescricaoMedicamento(resultado.getString("descricaoMedicamento"));
                    medicamento.setPrincipioAtivo(resultado.getString("principioAtivo"));
                    medicamento.setQtdMinima(resultado.getFloat("quantidadeMinima"));
                    medicamento.setStatus(resultado.getString("status"));
                    listaMedicamento.add(medicamento);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                ConnectionFactory.closeConnection(conexao, pstm, resultado);
                return listaMedicamento;
            }
        }

        @Override
        public Medicamento retrieve(int pk) {
            Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement pstm = null;
            ResultSet resultado = null;
            Medicamento medicamento = new Medicamento();

            String sqlInstrucao = " Select id, descricaoMedicamento, principioAtivo, quantidadeMinima, status"
                    + " From medicamento Where medicamento.id = ?";

            try {
                pstm = conexao.prepareStatement(sqlInstrucao);
                pstm.setInt(1, pk);
                resultado = pstm.executeQuery();
                while (resultado.next()) {
                    medicamento.setId(resultado.getInt("id"));
                    medicamento.setDescricaoMedicamento(resultado.getString("descricaoMedicamento"));
                    medicamento.setPrincipioAtivo(resultado.getString("principioAtivo"));
                    medicamento.setQtdMinima(resultado.getFloat("quantidadeMinima"));
                    medicamento.setStatus(resultado.getString("status"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                ConnectionFactory.closeConnection(conexao, pstm, resultado);
                return medicamento;
            }
        }

        @Override
        public List<Medicamento> retrieve(String parametro, String atributo) {

            Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement pstm = null;
            ResultSet resultado = null;
            List<Medicamento> listaMedicamento = new ArrayList<>();

            String sqlInstrucao = " Select id, descricaoMedicamento, principioAtivo, quantidadeMinima, status"
                    + " From medicamento Where " + atributo + " like ?";

            try {
                pstm = conexao.prepareStatement(sqlInstrucao);
                pstm.setString(1, "%" + parametro + "%");
                resultado = pstm.executeQuery();
                while (resultado.next()) {
                    Medicamento medicamento = new Medicamento();
                    medicamento.setId(resultado.getInt("id"));
                    medicamento.setDescricaoMedicamento(resultado.getString("descricaoMedicamento"));
                    medicamento.setPrincipioAtivo(resultado.getString("principioAtivo"));
                    medicamento.setQtdMinima(resultado.getFloat("quantidadeMinima"));
                    medicamento.setStatus(resultado.getString("status"));
                    listaMedicamento.add(medicamento);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                ConnectionFactory.closeConnection(conexao, pstm, resultado);
                return listaMedicamento;
            }

        }

        @Override
        public void update(Medicamento objeto) {

            Connection conexao = ConnectionFactory.getConnection();
            String sqlInstrucao = " Update medicamento "
                    + " set "
                    + " medicamento.descricaoMedicamento = ? , "
                    + " medicamento.principioAtivo = ? , "
                    + " medicamento.quantidadeMinima = ? , "
                    + " medicamento.status = ? "
                    + " Where medicamento.id = ?";
            PreparedStatement pstm = null;
            try {
                pstm = conexao.prepareStatement(sqlInstrucao);
                pstm.setString(1, objeto.getDescricaoMedicamento());
                pstm.setString(2, objeto.getPrincipioAtivo());
                pstm.setFloat(3, objeto.getQtdMinima());
                pstm.setString(4, objeto.getStatus());
                pstm.setInt(5, objeto.getId());
                pstm.execute();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }finally{
                ConnectionFactory.closeConnection(conexao, pstm, null);
            }
        }

        @Override
        public void delete(Medicamento objeto) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    }
