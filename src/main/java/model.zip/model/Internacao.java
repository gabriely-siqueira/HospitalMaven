package model;

public class Internacao {
    private int id;
    private String dataInternacao;
    private String horaInternacao;
    private String dataAlta;
    private String horaAlta;
    private String observacao;
    private String status;

    public Internacao() {
    }

    public Internacao(int id, String dataHoraIntercacao, String dataHoraAlta, String observacao, String status) {
        this.id = id;
        this.dataInternacao = dataHoraIntercacao;
        this.dataAlta = dataHoraAlta;
        this.observacao = observacao;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Internacao{" + "id=" + id + ", dataHoraIntercacao=" + dataInternacao + ", dataHoraAlta=" + dataAlta + ", observacao=" + observacao + ", status=" + status + '}';
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataInternacao() {
        return dataInternacao;
    }

    public void setDataInternacao(String dataInternacao) {
        this.dataInternacao = dataInternacao;
    }

    public String getHoraInternacao() {
        return horaInternacao;
    }

    public void setHoraInternacao(String horaInternacao) {
        this.horaInternacao = horaInternacao;
    }

    public String getDataAlta() {
        return dataAlta;
    }

    public void setDataAlta(String dataAlta) {
        this.dataAlta = dataAlta;
    }

    public String getHoraAlta() {
        return horaAlta;
    }

    public void setHoraAlta(String horaAlta) {
        this.horaAlta = horaAlta;
    }

 

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
