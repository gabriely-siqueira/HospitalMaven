package model;

public class Jornada {
    private int id;
    private String dataInicial;
    private String dataFinal;
    private String cargaHoraria;

    public Jornada( int id, String dataInicial, String dataFinal, String cargaHoraria) {
        this.id = id;
        this.dataInicial = dataInicial;
        this.dataFinal = dataFinal;
        this.cargaHoraria = cargaHoraria;
    }

    public Jornada() {
    }

    @Override
    public String toString() {
        return "Jornada{" + "id=" + id +", dataIncial= " + dataInicial + ", dataFinal= " + dataFinal + ", cargaHoraria= " + cargaHoraria + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataInicial() {
        return dataInicial;
    }

    public void setDataInicial(String dataInicial) {
        this.dataInicial = dataInicial;
    }
    
    public String getDataIncial() {
        return dataInicial;
    }

    public void setDataIncial(String dataIncial) {
        this.dataInicial = dataIncial;
    }

    public String getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(String dataFinal) {
        this.dataFinal = dataFinal;
    }

    public String getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }
    
    
}
