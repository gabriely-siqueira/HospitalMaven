package model;

public class Fornecedor extends Pessoa {
    private String nomeFantasia;
    private String contato;

    public Fornecedor() {
    }

    public Fornecedor(String nomeFantasia, String contato) {
        this.nomeFantasia = nomeFantasia;
        this.contato = contato;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    @Override
    public String toString() {
        return "Fornecedor{" + "nomeFantasia=" + nomeFantasia + ", contato=" + contato + '}';
    }
}
